import { useState, type FormEvent } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { AppSkeleton, useMounted } from "@/components/guard";
import { Wordmark } from "@/components/logo";
import { buttonClass, fieldClass } from "@/components/ui";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>): { mode: "in" | "join" } => ({
    mode: search.mode === "join" ? "join" : "in",
  }),
  component: LoginPage,
});

function LoginPage() {
  const mounted = useMounted();
  const { user, isPending } = useCurrentUserState();
  const { mode } = Route.useSearch();
  if (!mounted || isPending) return <AppSkeleton />;
  if (user) return <Navigate to="/" />;
  return <LoginForm mode={mode} />;
}

function LoginForm({ mode }: { mode: "in" | "join" }) {
  const navigate = Route.useNavigate();
  const joining = mode === "join";
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onProvider(providerId: string) {
    setError(null);
    setBusy(true);
    try {
      await signIn(providerId, { callbackURL: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
      setBusy(false);
    }
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (busy) return;
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedName = name.trim();
    if (joining && !trimmedName) {
      setError("Add your name.");
      return;
    }
    if (!trimmedEmail.includes("@")) {
      setError("Enter a valid email.");
      return;
    }
    if (password.length < 8) {
      setError("Password needs at least 8 characters.");
      return;
    }
    setBusy(true);
    setError(null);
    const result = joining
      ? await authClient.signUp.email({ email: trimmedEmail, password, name: trimmedName })
      : await authClient.signIn.email({ email: trimmedEmail, password });
    if (result.error) {
      setError(result.error.message ?? (joining ? "Could not create the account." : "Could not sign in."));
      setBusy(false);
      return;
    }
    window.location.assign("/");
  }

  return (
    <div className="grid min-h-dvh bg-paper text-ink md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section className="flex flex-col bg-ink px-6 py-8 text-paper md:justify-between md:px-10 md:py-10">
        <Link to="/" className="text-paper">
          <Wordmark />
        </Link>
        <div className="mt-8 hidden max-w-md md:block">
          <h1 className="font-serif text-4xl font-medium leading-tight tracking-tight">Say it once. It rises.</h1>
          <p className="mt-4 text-base leading-relaxed text-paper/80">
            A small community. No follows to farm — just the room, newest first.
          </p>
        </div>
        <p className="mt-8 hidden text-sm text-paper/70 md:block">Posts, a profile, and settings. That's the whole app.</p>
      </section>
      <section className="flex items-center px-6 py-10">
        <div className="mx-auto w-full max-w-sm">
          <h1 className="font-serif text-3xl font-medium tracking-tight md:hidden">
            {joining ? "Join Chirpin" : "Sign in"}
          </h1>
          <h2 className="hidden font-serif text-3xl font-medium tracking-tight md:block">
            {joining ? "Create your account" : "Welcome back"}
          </h2>
          <p className="mt-2 text-sm text-mute">Google, X, or email.</p>
          {authEnabled ? (
            <div className="mt-6 space-y-3">
              {GROK_PROVIDERS.map((provider) => (
                <button
                  key={provider.providerId}
                  type="button"
                  disabled={busy}
                  onClick={() => void onProvider(provider.providerId)}
                  className={`${buttonClass("secondary")} w-full`}
                >
                  Continue with {provider.label}
                </button>
              ))}
              <div className="flex items-center gap-3 py-1 text-xs text-mute">
                <span className="h-px flex-1 bg-line" />
                or
                <span className="h-px flex-1 bg-line" />
              </div>
              <form onSubmit={(event) => void onSubmit(event)} className="space-y-3">
                {joining ? (
                  <label className="block">
                    <span className="text-sm font-medium">Name</span>
                    <input
                      value={name}
                      onChange={(event) => setName(event.target.value)}
                      autoComplete="name"
                      className={`${fieldClass} mt-2`}
                    />
                  </label>
                ) : null}
                <label className="block">
                  <span className="text-sm font-medium">Email</span>
                  <input
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    autoComplete="email"
                    spellCheck={false}
                    className={`${fieldClass} mt-2`}
                  />
                </label>
                <label className="block">
                  <span className="text-sm font-medium">Password</span>
                  <input
                    type="password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    autoComplete={joining ? "new-password" : "current-password"}
                    className={`${fieldClass} mt-2`}
                  />
                  {joining ? <span className="mt-1.5 block text-xs text-mute">At least 8 characters.</span> : null}
                </label>
                {error ? (
                  <p role="alert" className="rounded-xl bg-soft px-3 py-2 text-sm text-clay">
                    {error}
                  </p>
                ) : null}
                <button type="submit" disabled={busy} className={`${buttonClass()} w-full`}>
                  {busy ? "Please wait…" : joining ? "Create account" : "Sign in"}
                </button>
              </form>
              <p className="text-sm text-mute">
                {joining ? "Already joined?" : "New here?"}{" "}
                <button
                  type="button"
                  className="font-medium text-ink underline-offset-2 hover:underline"
                  onClick={() => {
                    setError(null);
                    void navigate({
                      search: { mode: joining ? "in" : "join" },
                      replace: true,
                    });
                  }}
                >
                  {joining ? "Sign in" : "Create an account"}
                </button>
              </p>
            </div>
          ) : (
            <p className="mt-6 text-sm text-mute">Sign-in is turned off.</p>
          )}
        </div>
      </section>
    </div>
  );
}
