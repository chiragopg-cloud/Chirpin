import { createFileRoute } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Feed } from "@/components/feed";
import { AppSkeleton, useMounted } from "@/components/guard";
import { Landing } from "@/components/landing";
import { AppShell } from "@/components/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const mounted = useMounted();
  const { user, isPending } = useCurrentUserState();
  if (!mounted || isPending) return <AppSkeleton />;
  if (!user) return <Landing />;
  return (
    <AppShell>
      <Feed />
    </AppShell>
  );
}
