import { createRootRoute, HeadContent, Link, Outlet, Scripts } from "@tanstack/react-router";
import "@fontsource-variable/outfit";
import "@fontsource-variable/fraunces";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Mark } from "@/components/logo";
import { buttonClass } from "@/components/ui";
import appCss from "../styles.css?url";

const APP_NAME = "Chirpin";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "description", content: "Chirpin is your place to follow people, share moments, and join conversations." },
      { name: "theme-color", content: "#f8f7fc" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: Root,
  notFoundComponent: NotFound,
});

function Root() {
  return (
    <html lang="en" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 text-center text-ink">
      <div>
        <Mark className="mx-auto size-10" />
        <h1 className="mt-4 font-serif text-3xl font-medium">This page isn't in the room</h1>
        <p className="mt-2 text-sm text-mute">The link might be old.</p>
        <Link to="/" className={`${buttonClass()} mt-6`}>
          Go home
        </Link>
      </div>
    </main>
  );
}
