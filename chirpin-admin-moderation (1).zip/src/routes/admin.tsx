import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BadgeCheck, Crown, ShieldCheck, Users } from "lucide-react";
import { listAdminProfiles, setProfileBadges, listAdminPosts, adminDeletePost, setAccountBan, listBlockedWords, addBlockedWord, removeBlockedWord } from "@/lib/admin.functions";
import { useMe } from "@/components/shell";
import { Guard } from "@/components/guard";
import { Avatar } from "@/components/ui";
import { ProfileBadges } from "@/components/profile-badges";

export const Route = createFileRoute("/admin")({ component: AdminPage });
type Member = Awaited<ReturnType<typeof listAdminProfiles>>[number];
function AdminPage() { return <Guard><AdminPanel /></Guard>; }
function AdminPanel() {
  const { me } = useMe();
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState<string | null>(null);
  const [posts, setPosts] = useState<Awaited<ReturnType<typeof listAdminPosts>>>([]);
  const [words, setWords] = useState<Awaited<ReturnType<typeof listBlockedWords>>>([]);
  const [newWord, setNewWord] = useState("");
  async function refresh() { setLoading(true); setError(""); try { const [m,p,w] = await Promise.all([listAdminProfiles(),listAdminPosts(),listBlockedWords()]); setMembers(m); setPosts(p); setWords(w); } catch (e) { setError(e instanceof Error ? e.message : "Could not load admin data."); } finally { setLoading(false); } }
  useEffect(() => { void refresh(); }, []);
  async function update(member: Member, patch: Partial<Pick<Member, "isVerified" | "isVip">>) {
    const next = { ...member, ...patch }; setSaving(member.userId); setError("");
    try { await setProfileBadges({ data: { userId: member.userId, isVerified: next.isVerified, isVip: next.isVip } }); setMembers((all) => all.map((item) => item.userId === member.userId ? next : item)); }
    catch (e) { setError(e instanceof Error ? e.message : "Badge update failed."); } finally { setSaving(null); }
  }
  async function ban(member: Member) { const banned=!member.isBanned; const reason=banned ? (window.prompt("Reason for the account ban? (optional)") ?? "") : ""; try { await setAccountBan({data:{userId:member.userId,banned,reason}}); setMembers(all=>all.map(x=>x.userId===member.userId?{...x,isBanned:banned}:x)); } catch(e) { setError(e instanceof Error?e.message:"Could not update ban."); } }
  async function deletePost(id:number) { if(!window.confirm("Delete this post and its attached media permanently?")) return; try { await adminDeletePost({data:id}); setPosts(all=>all.filter(p=>p.id!==id)); } catch(e) { setError(e instanceof Error?e.message:"Could not delete post."); } }
  async function addWord() { try { await addBlockedWord({data:newWord}); setNewWord(""); setWords(await listBlockedWords()); } catch(e) { setError(e instanceof Error?e.message:"Could not add word."); } }
  async function removeWord(id:number) { try { await removeBlockedWord({data:id}); setWords(all=>all.filter(w=>w.id!==id)); } catch(e) { setError(e instanceof Error?e.message:"Could not remove word."); } }
  if (!me?.isAdmin) return <section className="p-8 text-center"><ShieldCheck className="mx-auto size-10 text-clay"/><h1 className="mt-3 text-xl font-semibold">Admin access only</h1><p className="mt-2 text-sm text-mute">This area is restricted to Chirpin administrators.</p></section>;
  return <section className="p-5 md:p-7"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-2xl bg-violet-100 text-violet-700"><ShieldCheck /></div><div><p className="text-xs font-semibold uppercase tracking-wider text-violet-700">Chirpin control room</p><h1 className="text-2xl font-semibold">Admin panel</h1></div></div>
    <div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-2xl border border-line bg-paper p-4"><Users className="size-5 text-mute"/><p className="mt-2 text-2xl font-semibold">{members.length}</p><p className="text-xs text-mute">Members shown</p></div><div className="rounded-2xl border border-line bg-paper p-4"><BadgeCheck className="size-5 text-sky-600"/><p className="mt-2 text-2xl font-semibold">{members.filter(m=>m.isVerified).length}</p><p className="text-xs text-mute">Verified members</p></div></div>
    {error ? <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p> : null}
    <div className="mt-7 flex items-center justify-between"><h2 className="font-semibold">Member badges</h2><button className="text-sm font-medium text-violet-700" onClick={()=>void refresh()}>Refresh</button></div>
    {loading ? <p className="py-8 text-sm text-mute">Loading members…</p> : <div className="mt-3 divide-y divide-line rounded-2xl border border-line">{members.map(member=><div key={member.userId} className="flex flex-wrap items-center gap-3 p-3"><Avatar name={member.displayName} url={null}/><div className="min-w-0 flex-1"><p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold">{member.displayName}<ProfileBadges verified={member.isVerified} vip={member.isVip}/></p><p className="truncate text-xs text-mute">@{member.handle} · {member.email}</p></div><div className="flex items-center gap-3"><label className="flex items-center gap-1.5 text-xs"><input type="checkbox" checked={member.isVerified} disabled={saving===member.userId} onChange={e=>void update(member,{isVerified:e.target.checked})}/>Verified</label><button className={`rounded-lg px-2 py-1 text-xs font-semibold ${member.isBanned?"bg-emerald-100 text-emerald-800":"bg-red-100 text-red-700"}`} onClick={()=>void ban(member)}>{member.isBanned?"Unban":"Ban"}</button><label className="flex items-center gap-1.5 text-xs"><input type="checkbox" checked={member.isVip} disabled={saving===member.userId} onChange={e=>void update(member,{isVip:e.target.checked})}/>VIP</label></div></div>)}</div>}
    <div className="mt-8"><h2 className="font-semibold">Recent posts & media</h2><div className="mt-3 space-y-2">{posts.map(post=><div key={post.id} className="flex items-center gap-3 rounded-xl border border-line p-3"><div className="min-w-0 flex-1"><p className="text-xs text-mute">@{post.handle} · {post.mediaType ?? "text post"}</p><p className="truncate text-sm">{post.body || "Media post"}</p></div><button onClick={()=>void deletePost(post.id)} className="rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">Delete</button></div>)}</div></div>
    <div className="mt-8"><h2 className="font-semibold">Blocked words</h2><p className="mt-1 text-xs text-mute">Words added here are blocked in all new posts and replies.</p><div className="mt-3 flex gap-2"><input value={newWord} onChange={e=>setNewWord(e.target.value)} placeholder="Add one word" className="min-w-0 flex-1 rounded-xl border border-line bg-paper px-3 py-2 text-sm"/><button onClick={()=>void addWord()} className="rounded-xl bg-violet-700 px-4 py-2 text-sm font-semibold text-white">Add</button></div><div className="mt-3 flex flex-wrap gap-2">{words.map(word=><span key={word.id} className="flex items-center gap-2 rounded-full bg-violet-50 px-3 py-1 text-xs text-violet-800">{word.word}<button onClick={()=>void removeWord(word.id)} aria-label={`Remove ${word.word}`}>×</button></span>)}</div></div>
    <p className="mt-4 text-xs leading-relaxed text-mute">Admin access is granted only to email addresses listed in the server-side ADMIN_EMAILS setting. Members cannot grant themselves badges.</p>
  </section>;
}
