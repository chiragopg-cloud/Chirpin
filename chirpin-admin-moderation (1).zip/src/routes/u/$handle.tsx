import { createFileRoute } from "@tanstack/react-router";
import { Guard } from "@/components/guard";
import { ProfileView } from "@/components/profile-view";

export const Route = createFileRoute("/u/$handle")({
  component: HandlePage,
});

function HandlePage() {
  const { handle } = Route.useParams();
  return (
    <Guard>
      <ProfileView handle={handle} />
    </Guard>
  );
}
