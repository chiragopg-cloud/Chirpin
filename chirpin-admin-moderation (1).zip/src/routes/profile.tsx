import { createFileRoute } from "@tanstack/react-router";
import { Guard } from "@/components/guard";
import { ProfileView } from "@/components/profile-view";

export const Route = createFileRoute("/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  return (
    <Guard>
      <ProfileView />
    </Guard>
  );
}
