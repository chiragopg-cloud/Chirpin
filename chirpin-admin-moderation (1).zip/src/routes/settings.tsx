import { createFileRoute } from "@tanstack/react-router";
import { Guard } from "@/components/guard";
import { SettingsForm } from "@/components/settings-form";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <Guard>
      <SettingsForm />
    </Guard>
  );
}
