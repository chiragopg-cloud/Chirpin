import { BadgeCheck, Crown, ShieldCheck } from "lucide-react";

export function ProfileBadges({ verified, vip, admin, className = "" }: { verified?: boolean; vip?: boolean; admin?: boolean; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1 align-middle ${className}`} aria-label={[admin ? "Admin" : "", verified ? "Verified" : "", vip ? "VIP" : ""].filter(Boolean).join(", ") || undefined}>
      {admin ? <span title="Chirpin administrator" className="inline-flex items-center gap-0.5 rounded-full bg-slate-900 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white"><ShieldCheck className="size-3" />Admin</span> : null}
      {verified ? <BadgeCheck className="size-[1em] shrink-0 text-sky-600" fill="currentColor" stroke="white" aria-label="Verified" /> : null}
      {vip ? <span title="VIP member" className="inline-flex items-center gap-0.5 rounded-full bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-violet-700"><Crown className="size-3" />VIP</span> : null}
    </span>
  );
}
