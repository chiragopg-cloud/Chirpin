import { useEffect, useState, useSyncExternalStore, type FormEvent, type ReactNode } from "react";
import { LogOut } from "lucide-react";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { updateProfile } from "@/lib/community.functions";
import { explainError } from "@/lib/format";
import { BIO_MAX, HANDLE_MAX, HANDLE_RE, HEADLINE_MAX, LOCATION_MAX, NAME_MAX } from "@/lib/limits";
import { useMe } from "@/components/shell";
import { buttonClass, fieldClass } from "@/components/ui";

const subscribeNothing = () => () => {};
const noGateOnServer = () => false;

type FormState = {
  displayName: string;
  handle: string;
  headline: string;
  bio: string;
  location: string;
};

export function SettingsForm() {
  const user = useCurrentUser();
  const { me, status, error, refresh } = useMe();
  const [form, setForm] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const gate = useSyncExternalStore(subscribeNothing, hasGateSessionMarker, noGateOnServer);
  const [signingOut, setSigningOut] = useState(false);
  const [signOutFailed, setSignOutFailed] = useState(false);

  useEffect(() => {
    if (!me || form) return;
    setForm({
      displayName: me.displayName,
      handle: me.handle,
      headline: me.headline,
      bio: me.bio,
      location: me.location,
    });
  }, [me, form]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!form || saving) return;
    setSaving(true);
    setSaved(false);
    setMessage(null);
    if (!form.displayName.trim()) {
      setMessage("Name is required.");
      setSaving(false);
      return;
    }
    if (!HANDLE_RE.test(form.handle)) {
      setMessage("Handle is 3–20 letters, numbers, or underscores.");
      setSaving(false);
      return;
    }
    try {
      const result = await updateProfile({ data: form });
      if (!result.ok) {
        setMessage(result.message);
        return;
      }
      setForm({
        displayName: result.profile.displayName,
        handle: result.profile.handle,
        headline: result.profile.headline,
        bio: result.profile.bio,
        location: result.profile.location,
      });
      await refresh();
      setSaved(true);
    } catch (err) {
      setMessage(explainError(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="px-4 py-6 md:px-5">
      <h1 className="text-base font-semibold">Settings</h1>
      <p className="mt-1 text-sm text-mute">How you show up in the room.</p>
      {status === "error" && !form ? <p className="mt-6 text-sm text-clay">{error}</p> : null}
      {!form ? (
        <div className="mt-6 space-y-4">
          <div className="h-11 animate-pulse rounded-xl bg-soft" />
          <div className="h-11 animate-pulse rounded-xl bg-soft" />
          <div className="h-11 animate-pulse rounded-xl bg-soft" />
        </div>
      ) : (
        <form onSubmit={(event) => void onSubmit(event)} className="mt-6 space-y-5">
          <Field label="Name">
            <input
              value={form.displayName}
              maxLength={NAME_MAX}
              autoComplete="name"
              onChange={(event) => {
                setSaved(false);
                setForm({ ...form, displayName: event.target.value });
              }}
              className={fieldClass}
            />
          </Field>
          <Field label="Handle" hint="Letters, numbers, underscores. This is your public address.">
            <div className="flex h-11 items-center rounded-xl border border-line bg-paper px-3 focus-within:border-ink">
              <span className="text-sm text-mute">@</span>
              <input
                value={form.handle}
                maxLength={HANDLE_MAX}
                spellCheck={false}
                autoCapitalize="off"
                autoCorrect="off"
                onChange={(event) => {
                  setSaved(false);
                  setForm({
                    ...form,
                    handle: event.target.value.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, HANDLE_MAX),
                  });
                }}
                className="h-full w-full bg-transparent pl-1 text-sm outline-none"
              />
            </div>
          </Field>
          <Field label="Headline">
            <input
              value={form.headline}
              maxLength={HEADLINE_MAX}
              placeholder="What you're about"
              onChange={(event) => {
                setSaved(false);
                setForm({ ...form, headline: event.target.value });
              }}
              className={fieldClass}
            />
          </Field>
          <Field label="Bio">
            <textarea
              value={form.bio}
              maxLength={BIO_MAX}
              rows={4}
              onChange={(event) => {
                setSaved(false);
                setForm({ ...form, bio: event.target.value });
              }}
              className={`${fieldClass} h-auto min-h-28 py-3 leading-relaxed`}
            />
          </Field>
          <Field label="Location">
            <input
              value={form.location}
              maxLength={LOCATION_MAX}
              placeholder="City"
              onChange={(event) => {
                setSaved(false);
                setForm({ ...form, location: event.target.value });
              }}
              className={fieldClass}
            />
          </Field>
          <div className="flex items-center gap-3">
            <button type="submit" disabled={saving} className={buttonClass()}>
              {saving ? "Saving…" : "Save"}
            </button>
            <p aria-live="polite" className="text-sm text-mute">
              {saved ? "Saved" : ""}
            </p>
          </div>
          {message ? (
            <p role="alert" className="text-sm text-clay">
              {message}
            </p>
          ) : null}
        </form>
      )}

      <div className="mt-10 border-t border-line pt-6">
        <h2 className="text-sm font-semibold">Account</h2>
        {user?.primaryEmail ? <p className="mt-2 text-sm text-mute">{user.primaryEmail}</p> : null}
        {authEnabled && !gate ? (
          <div className="mt-4">
            <button
              type="button"
              disabled={signingOut}
              onClick={() => {
                setSigningOut(true);
                setSignOutFailed(false);
                void signOut("/").catch(() => {
                  setSigningOut(false);
                  setSignOutFailed(true);
                });
              }}
              className={buttonClass("secondary")}
            >
              <LogOut className="size-4" aria-hidden="true" />
              {signingOut ? "Signing out…" : "Sign out"}
            </button>
            {signOutFailed ? <p className="mt-2 text-sm text-clay">Couldn't sign out. Try again.</p> : null}
          </div>
        ) : (
          <p className="mt-3 text-sm text-mute">You're signed in with your Grok account.</p>
        )}
      </div>
    </section>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm font-medium">{label}</span>
      <div className="mt-2">{children}</div>
      {hint ? <span className="mt-1.5 block text-xs text-mute">{hint}</span> : null}
    </label>
  );
}
