import { useEffect, useState, type ReactNode } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Wordmark } from "@/components/logo";
import { AppShell } from "@/components/shell";

export function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}

export function AppSkeleton() {
  return (
    <div className="min-h-dvh bg-paper text-ink">
      <header className="mx-auto flex h-16 w-full max-w-6xl items-center px-5">
        <Wordmark />
      </header>
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-5 md:grid-cols-2">
        <div>
          <div className="h-9 w-4/5 animate-pulse rounded-full bg-line" />
          <div className="mt-3 h-9 w-2/3 animate-pulse rounded-full bg-line" />
          <div className="mt-6 h-4 w-full animate-pulse rounded-full bg-line" />
          <div className="mt-2 h-4 w-4/5 animate-pulse rounded-full bg-line" />
        </div>
        <div className="h-64 animate-pulse rounded-3xl bg-card shadow-card" />
      </div>
    </div>
  );
}

export function Guard({ children }: { children: ReactNode }) {
  const mounted = useMounted();
  const { user, isPending } = useCurrentUserState();
  if (!mounted || isPending) return <AppSkeleton />;
  if (!user) return <RedirectToSignIn />;
  return <AppShell>{children}</AppShell>;
}
