import type { ReactNode } from "react";

export function LinkText({ text, className = "" }: { text: string; className?: string }) {
  const nodes: ReactNode[] = [];
  const re = /https?:\/\/[^\s]+/g;
  let last = 0;
  for (const match of text.matchAll(re)) {
    const start = match.index ?? 0;
    if (start > last) nodes.push(text.slice(last, start));
    const raw = match[0];
    const href = raw.replace(/[.,!?;:)]+$/, "");
    const trail = raw.slice(href.length);
    nodes.push(
      <a
        key={`${start}-${href}`}
        href={href}
        target="_blank"
        rel="noreferrer noopener"
        className="underline decoration-line underline-offset-2 hover:decoration-ink"
      >
        {href}
      </a>,
    );
    if (trail) nodes.push(trail);
    last = start + raw.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return <p className={`whitespace-pre-wrap break-words text-pretty ${className}`}>{nodes}</p>;
}
