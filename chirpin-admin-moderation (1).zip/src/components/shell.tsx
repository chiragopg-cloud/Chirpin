import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { CircleUser, House, Settings, ShieldCheck } from "lucide-react";
import { getMe, type Profile } from "@/lib/community.functions";
import { explainError } from "@/lib/format";
import { Wordmark } from "@/components/logo";
import { Avatar } from "@/components/ui";

type MeValue = {
  me: Profile | null;
  status: "loading" | "ready" | "error";
  error: string | null;
  refresh: () => Promise<void>;
};

const MeContext = createContext<MeValue | null>(null);

export function useMe() {
  const value = useContext(MeContext);
  if (!value) throw new Error("useMe must be used inside the app shell");
  return value;
}

const NAV = [
  { to: "/", label: "Home", icon: House },
  { to: "/profile", label: "Profile", icon: CircleUser },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

function isActive(path: string, to: string, handle?: string) {
  if (to === "/") return path === "/";
  if (to === "/settings") return path === "/settings";
  return path === "/profile" || (handle ? path === `/u/${handle}` : false);
}

function NavLinks({ handle, stacked, isAdmin }: { handle?: string; stacked?: boolean; isAdmin?: boolean }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  return (
    <ul className={stacked ? `grid ${isAdmin ? "grid-cols-4" : "grid-cols-3"}` : "flex flex-col gap-1"}>
      {NAV.map((item) => {
        const active = isActive(path, item.to, handle);
        const Icon = item.icon;
        return (
          <li key={item.to}>
            <Link
              to={item.to}
              aria-current={active ? "page" : undefined}
              className={
                stacked
                  ? `flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium ${active ? "text-ink" : "text-mute"}`
                  : `flex h-11 items-center gap-3 rounded-full px-3 text-sm font-medium ${active ? "bg-soft text-ink" : "text-mute hover:bg-soft hover:text-ink"}`
              }
            >
              <Icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
              {item.label}
            </Link>
          </li>
        );
      })}
      {isAdmin ? <li><Link to="/admin" aria-current={path === "/admin" ? "page" : undefined} className={stacked ? `flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium ${path === "/admin" ? "text-violet-700" : "text-mute"}` : `flex h-11 items-center gap-3 rounded-full px-3 text-sm font-medium ${path === "/admin" ? "bg-violet-50 text-violet-700" : "text-violet-700 hover:bg-soft"}`}><ShieldCheck className="size-5"/>Admin</Link></li> : null}
    </ul>
  );
}

function YouCard() {
  const { me, status, error, refresh } = useMe();
  if (status === "loading") {
    return <div className="h-36 animate-pulse rounded-3xl bg-card shadow-card" />;
  }
  if (!me) {
    return (
      <div className="rounded-3xl bg-card p-4 shadow-card">
        <p className="text-sm text-clay">{error ?? "Couldn't load your profile."}</p>
        <button type="button" onClick={() => void refresh()} className="mt-3 text-sm font-medium underline-offset-2 hover:underline">
          Try again
        </button>
      </div>
    );
  }
  return (
    <Link to="/profile" className="block rounded-3xl bg-card p-4 shadow-card transition-[box-shadow] duration-150 hover:shadow-card">
      <div className="flex items-center gap-3">
        <Avatar name={me.displayName} url={me.avatarUrl} />
        <div className="min-w-0">
          <p className="truncate font-medium">{me.displayName}</p>
          <p className="truncate text-sm text-mute">@{me.handle}</p>
        </div>
      </div>
      <p className="mt-3 text-sm text-pretty text-mute">
        {me.headline || "Add a headline in settings."}
      </p>
      <p className="mt-4 text-sm">
        <span className="font-semibold tabular-nums">{me.postCount}</span>{" "}
        <span className="text-mute">{me.postCount === 1 ? "post" : "posts"}</span>
      </p>
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Profile | null>(null);
  const [status, setStatus] = useState<MeValue["status"]>("loading");
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const profile = await getMe();
      setMe(profile);
      setStatus("ready");
      setError(null);
    } catch (err) {
      setStatus("error");
      setError(explainError(err));
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const value = useMemo(() => ({ me, status, error, refresh }), [me, status, error, refresh]);

  return (
    <MeContext.Provider value={value}>
      <div className="min-h-dvh bg-paper text-ink">
        <header className="sticky top-0 z-20 flex h-14 items-center border-b border-line bg-card px-4 md:hidden">
          <Link to="/" className="text-ink">
            <Wordmark />
          </Link>
        </header>
        <div className="mx-auto grid w-full max-w-6xl md:grid-cols-[220px_minmax(0,1fr)] lg:grid-cols-[220px_minmax(0,1fr)_280px]">
          <aside className="sticky top-0 hidden h-dvh flex-col px-4 py-6 md:flex">
            <Link to="/" className="px-3 text-ink">
              <Wordmark />
            </Link>
            <nav aria-label="Primary" className="mt-8">
              <NavLinks handle={me?.handle} isAdmin={me?.isAdmin} />
            </nav>
          </aside>
          <div className="pb-nav min-w-0 bg-card md:min-h-dvh md:border-x md:border-line">{children}</div>
          <aside className="sticky top-0 hidden h-dvh px-5 py-6 lg:block">
            <YouCard />
            <p className="mt-4 px-1 text-sm leading-relaxed text-mute">
              One room. No ranking. Whatever was said last sits at the top.
            </p>
          </aside>
        </div>
        <nav aria-label="Primary" className="safe-bottom fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card md:hidden">
          <NavLinks handle={me?.handle} stacked isAdmin={me?.isAdmin} />
        </nav>
      </div>
    </MeContext.Provider>
  );
}
