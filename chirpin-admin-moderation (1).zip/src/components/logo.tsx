export function Mark({ className = "size-7" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <path d="M7 23.5V15a9 9 0 0 1 18 0v8.5" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" />
      <path d="M11 23.5v-6a5 5 0 0 1 10 0v6" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" />
      <path d="M16 24v3" stroke="#7650c9" strokeWidth="3" strokeLinecap="round" />
      <path d="M24.5 7.5l2-2M27 13h2" stroke="#7650c9" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function Wordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <Mark />
      <span className="font-serif text-xl font-medium tracking-tight">Chirpin</span>
    </span>
  );
}
