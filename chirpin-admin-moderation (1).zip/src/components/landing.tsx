import { Link } from "@tanstack/react-router";
import { ArrowUp, Settings, UserRound } from "lucide-react";
import { Wordmark } from "@/components/logo";
import { buttonClass } from "@/components/ui";

const POINTS = [
  {
    title: "Your people, your feed",
    body: "A fresh community feed for the people you follow.",
    icon: ArrowUp,
  },
  {
    title: "A real profile",
    body: "Show your personality and connect with others.",
    icon: UserRound,
  },
  {
    title: "Settings that stay quiet",
    body: "Make Chirpin feel like yours.",
    icon: Settings,
  },
];

export function Landing() {
  return (
    <div className="flex min-h-dvh flex-col bg-paper text-ink">
      <header className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-5">
        <Wordmark />
        <Link to="/login" search={{ mode: "in" }} className="text-sm font-medium">
          Sign in
        </Link>
      </header>
      <main className="mx-auto grid w-full max-w-6xl flex-1 content-start gap-10 px-5 py-6 md:content-center md:grid-cols-2 md:items-center md:py-10">
        <div>
          <h1 className="rise font-serif text-4xl font-medium leading-tight tracking-tight md:text-5xl">
            A little more social. A lot more you.
          </h1>
          <p className="rise rise-2 mt-4 max-w-md text-base leading-relaxed text-mute">
            Follow people you like, join conversations, and share photos and videos with your community.
          </p>
          <div className="rise rise-3 mt-6 flex flex-wrap gap-3">
            <Link to="/login" search={{ mode: "join" }} className={buttonClass()}>
              Join Chirpin
            </Link>
            <Link to="/login" search={{ mode: "in" }} className={buttonClass("secondary")}>
              I have an account
            </Link>
          </div>
        </div>
        <div className="rounded-3xl bg-card p-3 shadow-card">
          <div className="px-3 pt-2 pb-3">
            <p className="text-sm font-semibold">Home</p>
            <p className="text-xs text-mute">Newest first</p>
          </div>
          <div className="rounded-xl bg-paper px-3 py-3 text-sm text-mute">Share something with the room</div>
          <ul className="mt-1">
            {POINTS.map((point) => {
              const Icon = point.icon;
              return (
                <li key={point.title} className="flex gap-3 border-t border-line px-2 py-3">
                  <span className="grid size-10 shrink-0 place-items-center rounded-full bg-soft">
                    <Icon className="size-4" strokeWidth={1.75} aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-medium">{point.title}</span>
                    <span className="mt-0.5 block text-sm text-mute">{point.body}</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      </main>
    </div>
  );
}
