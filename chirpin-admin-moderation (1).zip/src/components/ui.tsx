export const fieldClass =
  "h-11 w-full rounded-xl border border-line bg-paper px-3 text-sm text-ink outline-none transition-[border-color] duration-150 placeholder:text-mute focus-visible:border-clay";

export const areaClass =
  "min-h-28 w-full resize-none rounded-xl border border-line bg-paper px-3 py-3 text-sm leading-relaxed text-ink outline-none transition-[border-color] duration-150 placeholder:text-mute focus-visible:border-clay";

export function buttonClass(variant: "primary" | "secondary" | "ghost" = "primary") {
  const base =
    "press inline-flex h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-clay disabled:opacity-50";
  if (variant === "secondary") return `${base} bg-card text-ink shadow-card hover:bg-soft`;
  if (variant === "ghost") return `${base} bg-transparent text-ink hover:bg-soft`;
  return `${base} bg-clay text-white hover:bg-clay/90`;
}

const avatarSize = {
  sm: "size-8 text-xs",
  md: "size-11 text-sm",
  lg: "size-20 text-2xl font-medium",
} as const;

export function Avatar({
  name,
  url,
  size = "md",
}: {
  name: string;
  url: string | null;
  size?: keyof typeof avatarSize;
}) {
  const box = avatarSize[size];
  const safe = url && url.startsWith("https://") ? url : null;
  if (safe) {
    return (
      <img
        src={safe}
        alt=""
        referrerPolicy="no-referrer"
        loading="lazy"
        className={`${box} rounded-full object-cover outline outline-1 -outline-offset-1 outline-ink/10`}
      />
    );
  }
  const initial = name.trim().slice(0, 1).toUpperCase() || "A";
  return (
    <span className={`${box} grid place-items-center rounded-full bg-soft font-medium text-ink`}>
      {initial}
    </span>
  );
}
