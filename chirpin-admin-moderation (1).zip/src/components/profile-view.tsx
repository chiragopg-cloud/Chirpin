import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { MapPin, UserPlus, UserCheck } from "lucide-react";
import { getByHandle, getMe, listPosts, toggleFollow, type Post, type Profile } from "@/lib/community.functions";
import { explainError, formatJoined } from "@/lib/format";
import { Mark } from "@/components/logo";
import { PostCard } from "@/components/post-card";
import { useMe } from "@/components/shell";
import { Avatar, buttonClass } from "@/components/ui";
import { ProfileBadges } from "@/components/profile-badges";

type State =
  | { status: "loading" }
  | { status: "missing" }
  | { status: "error"; message: string }
  | { status: "ready"; profile: Profile; posts: Post[] };

export function ProfileView({ handle }: { handle?: string }) {
  const { refresh } = useMe();
  const [state, setState] = useState<State>({ status: "loading" });
  const [followBusy, setFollowBusy] = useState(false);

  useEffect(() => {
    let cancel = false;
    setState({ status: "loading" });
    void (async () => {
      try {
        const [profile, posts] = await Promise.all([
          handle ? getByHandle({ data: handle }) : getMe(),
          listPosts({ data: handle ?? null }),
        ]);
        if (cancel) return;
        if (!profile) setState({ status: "missing" });
        else setState({ status: "ready", profile, posts });
      } catch (err) {
        if (!cancel) setState({ status: "error", message: explainError(err) });
      }
    })();
    return () => {
      cancel = true;
    };
  }, [handle]);

  if (state.status === "loading") {
    return (
      <div>
        <div className="h-24 animate-pulse bg-soft" />
        <div className="px-5 py-5">
          <div className="size-20 animate-pulse rounded-full bg-line" />
          <div className="mt-4 h-7 w-40 animate-pulse rounded-full bg-line" />
          <div className="mt-2 h-4 w-24 animate-pulse rounded-full bg-line" />
        </div>
      </div>
    );
  }

  if (state.status === "missing") {
    return (
      <div className="px-6 py-16 text-center">
        <Mark className="mx-auto size-10" />
        <h1 className="mt-4 font-serif text-2xl font-medium">No one by that name</h1>
        <p className="mt-2 text-sm text-mute">That profile isn't in the room.</p>
        <Link to="/" className={`${buttonClass()} mt-6`}>
          Back home
        </Link>
      </div>
    );
  }

  if (state.status === "error") {
    return (
      <div className="px-6 py-16 text-center">
        <p className="text-sm text-clay">{state.message}</p>
      </div>
    );
  }

  const { profile, posts } = state;
  async function onFollow() {
    if (followBusy || profile.isSelf) return;
    setFollowBusy(true);
    try {
      const result = await toggleFollow({ data: profile.handle });
      if (result.ok) setState((current) => current.status === "ready" ? { ...current, profile: { ...current.profile, isFollowing: result.following, followerCount: result.followerCount } } : current);
    } finally { setFollowBusy(false); }
  }
  return (
    <section>
      <div className="relative h-24 overflow-hidden bg-soft">
        <Mark className="absolute -right-1 -top-4 size-28 text-ink/10" />
      </div>
      <div className="px-4 pb-2 md:px-5">
        <div className="-mt-8 w-fit rounded-full bg-card p-1">
          <Avatar name={profile.displayName} url={profile.avatarUrl} size="lg" />
        </div>
        <div className="mt-3 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="flex flex-wrap items-center gap-2 font-serif text-3xl font-medium tracking-tight">{profile.displayName}<ProfileBadges admin={profile.isAdmin} verified={profile.isVerified} vip={profile.isVip} /></h1>
            <p className="text-sm text-mute">@{profile.handle}</p>
          </div>
          {profile.isSelf ? (
            <Link to="/settings" className={`${buttonClass("secondary")} shrink-0`}>
              Edit
            </Link>
          ) : (
            <button type="button" onClick={() => void onFollow()} disabled={followBusy} className={`${buttonClass(profile.isFollowing ? "secondary" : "primary")} shrink-0`}>
              {profile.isFollowing ? <UserCheck className="size-4" /> : <UserPlus className="size-4" />}
              {followBusy ? "Please wait…" : profile.isFollowing ? "Following" : "Follow"}
            </button>
          )}
        </div>
        {profile.headline ? <p className="mt-3 text-sm font-medium">{profile.headline}</p> : null}
        {profile.bio ? <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-pretty">{profile.bio}</p> : null}
        <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-mute">
          {profile.location ? (
            <span className="inline-flex items-center gap-1">
              <MapPin className="size-3.5" strokeWidth={1.75} aria-hidden="true" />
              {profile.location}
            </span>
          ) : null}
          <span>Joined {formatJoined(profile.joinedAt)}</span>
        </div>
        <dl className="mt-5 flex gap-6 border-y border-line py-3">
          <div>
            <dt className="text-xs text-mute">Posts</dt>
            <dd className="text-lg font-semibold tabular-nums">{profile.postCount}</dd>
          </div>
          <div>
            <dt className="text-xs text-mute">Followers</dt>
            <dd className="text-lg font-semibold tabular-nums">{profile.followerCount}</dd>
          </div>
          <div>
            <dt className="text-xs text-mute">Following</dt>
            <dd className="text-lg font-semibold tabular-nums">{profile.followingCount}</dd>
          </div>
        </dl>
      </div>
      {posts.length === 0 ? (
        <div className="px-5 py-12 text-center">
          <p className="font-medium">No posts yet</p>
          <p className="mt-1 text-sm text-mute">
            {profile.isSelf ? "What you post shows up here, and at the top of Home." : "Nothing from this person yet."}
          </p>
        </div>
      ) : (
        posts.map((post) => (
          <PostCard
            key={post.id}
            post={post}
            onRemove={() => {
              setState((current) =>
                current.status === "ready"
                  ? {
                      ...current,
                      posts: current.posts.filter((item) => item.id !== post.id),
                      profile: {
                        ...current.profile,
                        postCount: Math.max(0, current.profile.postCount - 1),
                      },
                    }
                  : current,
              );
              void refresh();
            }}
          />
        ))
      )}
    </section>
  );
}
