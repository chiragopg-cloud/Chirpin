import { useEffect, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { Heart, MessageCircle } from "lucide-react";
import {
  addComment,
  deleteComment,
  deletePost,
  listComments,
  toggleLike,
  type Comment,
  type Post,
} from "@/lib/community.functions";
import { explainError, timeAgo } from "@/lib/format";
import { COMMENT_MAX } from "@/lib/limits";
import { LinkText } from "@/components/link-text";
import { Avatar, buttonClass, fieldClass } from "@/components/ui";
import { ProfileBadges } from "@/components/profile-badges";

export function PostCard({ post, onRemove }: { post: Post; onRemove: () => void }) {
  const [liked, setLiked] = useState(post.liked);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [likePending, setLikePending] = useState(false);
  const [open, setOpen] = useState(false);
  const [comments, setComments] = useState<Comment[] | null>(null);
  const [commentCount, setCommentCount] = useState(post.commentCount);
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [replyError, setReplyError] = useState<string | null>(null);
  const [replying, setReplying] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    setLiked(post.liked);
    setLikeCount(post.likeCount);
    setCommentCount(post.commentCount);
  }, [post.id, post.liked, post.likeCount, post.commentCount]);

  async function onLike() {
    if (likePending) return;
    const next = !liked;
    setLiked(next);
    setLikeCount((count) => Math.max(0, count + (next ? 1 : -1)));
    setLikePending(true);
    try {
      const result = await toggleLike({ data: post.id });
      if (!result.ok) throw new Error(result.message);
      setLiked(result.liked);
      setLikeCount(result.likeCount);
    } catch {
      setLiked(post.liked);
      setLikeCount(post.likeCount);
    } finally {
      setLikePending(false);
    }
  }

  async function openThread() {
    const next = !open;
    setOpen(next);
    if (next && comments === null) {
      try {
        const rows = await listComments({ data: post.id });
        setComments(rows);
        setCommentCount(rows.length);
      } catch (err) {
        setReplyError(explainError(err));
        setComments([]);
      }
    }
  }

  async function onReply(event: FormEvent) {
    event.preventDefault();
    const body = draft.trim();
    if (!body || replying) return;
    setReplying(true);
    setReplyError(null);
    try {
      const result = await addComment({ data: { postId: post.id, body, parentId: replyTo } });
      if (!result.ok) throw new Error(result.message);
      setComments((current) => [...(current ?? []), result.comment]);
      setCommentCount((count) => count + 1);
      setDraft("");
      setReplyTo(null);
    } catch (err) {
      setReplyError(explainError(err));
    } finally {
      setReplying(false);
    }
  }

  async function onDeleteComment(id: number) {
    const result = await deleteComment({ data: id });
    if (!result.ok) {
      setReplyError(result.message);
      return;
    }
    setComments((current) => (current ?? []).filter((comment) => comment.id !== id));
    setCommentCount((count) => Math.max(0, count - 1));
  }

  async function onDelete() {
    setDeleting(true);
    setDeleteError(null);
    try {
      const result = await deletePost({ data: post.id });
      if (!result.ok) throw new Error(result.message);
      onRemove();
    } catch (err) {
      setDeleteError(explainError(err));
      setDeleting(false);
    }
  }

  return (
    <article className="border-b border-line px-4 py-4 md:px-5">
      <div className="flex gap-3">
        <Link to="/u/$handle" params={{ handle: post.author.handle }} className="shrink-0">
          <Avatar name={post.author.displayName} url={post.author.avatarUrl} />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex min-w-0 items-baseline gap-x-2">
            <Link
              to="/u/$handle"
              params={{ handle: post.author.handle }}
              className="truncate font-medium hover:underline"
            >
              {post.author.displayName}<ProfileBadges verified={post.author.isVerified} vip={post.author.isVip} />
            </Link>
            <span className="shrink-0 text-sm text-mute">@{post.author.handle}</span>
            <span className="text-mute" aria-hidden="true">
              ·
            </span>
            <time dateTime={post.createdAt} className="shrink-0 text-sm text-mute tabular-nums">
              {timeAgo(post.createdAt)}
            </time>
          </div>
          {post.body ? <LinkText text={post.body} className="mt-1 text-base leading-relaxed" /> : null}
          {post.mediaUrl ? (
            <div className="mt-3 overflow-hidden rounded-2xl border border-line bg-soft">
              {post.mediaType === "video" ? <video src={post.mediaUrl} controls preload="metadata" className="max-h-[520px] w-full" /> : <img src={post.mediaUrl} alt="Post attachment" loading="lazy" className="max-h-[520px] w-full object-contain" />}
            </div>
          ) : null}
          <div className="mt-1 flex items-center gap-1">
            <button
              type="button"
              onClick={() => void onLike()}
              aria-pressed={liked}
              aria-label={liked ? "Unlike" : "Like"}
              className={`inline-flex h-11 items-center gap-1.5 rounded-full px-2 text-sm ${liked ? "text-clay" : "text-mute hover:bg-soft hover:text-ink"}`}
            >
              <span className="relative grid size-4">
                <Heart
                  data-show={liked ? "true" : "false"}
                  className="icon-swap col-start-1 row-start-1 size-4 fill-clay text-clay"
                  strokeWidth={1.75}
                  aria-hidden="true"
                />
                <Heart
                  data-show={liked ? "false" : "true"}
                  className="icon-swap col-start-1 row-start-1 size-4 fill-transparent text-mute"
                  strokeWidth={1.75}
                  aria-hidden="true"
                />
              </span>
              {likeCount > 0 ? <span className="tabular-nums">{likeCount}</span> : null}
            </button>
            <button
              type="button"
              onClick={() => void openThread()}
              aria-expanded={open}
              className="inline-flex h-11 items-center gap-1.5 rounded-full px-2 text-sm text-mute hover:bg-soft hover:text-ink"
            >
              <MessageCircle className="size-4" strokeWidth={1.75} aria-hidden="true" />
              {commentCount > 0 ? <span className="tabular-nums">{commentCount}</span> : <span>Reply</span>}
            </button>
            {post.mine ? (
              confirmDelete ? (
                <span className="inline-flex items-center">
                  <button
                    type="button"
                    onClick={() => void onDelete()}
                    disabled={deleting}
                    className="h-11 px-2 text-sm text-clay disabled:opacity-50"
                  >
                    {deleting ? "Deleting…" : "Confirm"}
                  </button>
                  <button type="button" onClick={() => setConfirmDelete(false)} className="h-11 px-2 text-sm text-mute">
                    Cancel
                  </button>
                </span>
              ) : (
                <button type="button" onClick={() => setConfirmDelete(true)} className="h-11 px-2 text-sm text-mute hover:text-clay">
                  Delete
                </button>
              )
            ) : null}
          </div>
          {deleteError ? <p className="text-sm text-clay">{deleteError}</p> : null}
          {open ? (
            <div className="mt-2">
              {comments === null ? (
                <p className="py-2 text-sm text-mute">Loading replies…</p>
              ) : comments.length === 0 ? (
                <p className="py-2 text-sm text-mute">No replies yet.</p>
              ) : (
                <ul>
                  {comments.map((comment) => (
                    <li key={comment.id} className={`flex gap-2 border-t border-line py-3 ${comment.parentId !== null ? "ml-8 border-l-2 border-l-clay/20 pl-3" : ""}`}>
                      <Link to="/u/$handle" params={{ handle: comment.author.handle }} className="shrink-0">
                        <Avatar name={comment.author.displayName} url={comment.author.avatarUrl} size="sm" />
                      </Link>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline gap-2">
                          <Link
                            to="/u/$handle"
                            params={{ handle: comment.author.handle }}
                            className="truncate text-sm font-medium hover:underline"
                          >
                            {comment.author.displayName}
                          </Link>
                          <time dateTime={comment.createdAt} className="shrink-0 text-xs text-mute tabular-nums">
                            {timeAgo(comment.createdAt)}
                          </time>
                        </div>
                        <LinkText text={comment.body} className="text-sm" />
                        <button type="button" onClick={() => { setReplyTo(comment.id); setDraft(`@${comment.author.handle} `); }} className="mt-1 mr-3 text-xs font-medium text-clay">Reply</button>
                        {comment.mine ? (
                          <button
                            type="button"
                            onClick={() => void onDeleteComment(comment.id)}
                            className="mt-1 text-xs text-mute hover:text-clay"
                          >
                            Delete
                          </button>
                        ) : null}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
              <form onSubmit={(event) => void onReply(event)} className="mt-2 flex items-center gap-2">
                <label className="min-w-0 flex-1">
                  <span className="sr-only">Reply</span>
                  <input
                    value={draft}
                    maxLength={COMMENT_MAX}
                    onChange={(event) => setDraft(event.target.value)}
                    placeholder={replyTo ? "Write a threaded reply" : "Write a reply"}
                    className={`${fieldClass} min-w-0`}
                  />
                </label>
                <button type="submit" disabled={replying || draft.trim().length === 0} className={`${buttonClass()} shrink-0 px-4`}>
                  {replying ? "Sending…" : "Send"}
                </button>
              </form>
              {replyTo !== null ? <button type="button" onClick={() => { setReplyTo(null); setDraft(""); }} className="mt-2 text-xs text-mute">Cancel threaded reply</button> : null}
              {replyError ? (
                <p role="alert" className="mt-2 text-sm text-clay">
                  {replyError}
                </p>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </article>
  );
}
