import { useCallback, useEffect, useState, type FormEvent } from "react";
import { createPost, listFeed, listFollowingFeed, type Post } from "@/lib/community.functions";
import { explainError } from "@/lib/format";
import { POST_MAX } from "@/lib/limits";
import { Mark } from "@/components/logo";
import { PostCard } from "@/components/post-card";
import { useMe } from "@/components/shell";
import { Avatar, areaClass, buttonClass } from "@/components/ui";

export function Feed() {
  const { me, refresh } = useMe();
  const [posts, setPosts] = useState<Post[] | null>(null);
  const [feedMode, setFeedMode] = useState<"all" | "following">("all");
  const [error, setError] = useState<string | null>(null);
  const [body, setBody] = useState("");
  const [posting, setPosting] = useState(false);
  const [media, setMedia] = useState<{ url: string; type: "image" | "video"; name: string } | null>(null);
  const [composerError, setComposerError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const rows = feedMode === "all" ? await listFeed() : await listFollowingFeed();
      setPosts(rows);
      setError(null);
    } catch (err) {
      setError(explainError(err));
    }
  }, [feedMode]);

  useEffect(() => {
    void load();
  }, [load]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    const text = body.trim();
    if ((!text && !media) || posting) return;
    setPosting(true);
    setComposerError(null);
    try {
      const result = await createPost({ data: { body: text, mediaUrl: media?.url ?? null, mediaType: media?.type ?? null } });
      if (!result.ok) {
        setComposerError(result.message);
        return;
      }
      setPosts((current) => [result.post, ...(current ?? [])]);
      setBody("");
      setMedia(null);
      void refresh();
    } catch (err) {
      setComposerError(explainError(err));
    } finally {
      setPosting(false);
    }
  }

  return (
    <section>
      <header className="sticky top-0 z-10 hidden border-b border-line bg-card px-5 py-3 md:block">
        <h1 className="text-base font-semibold">Home</h1>
        <div className="mt-2 flex gap-2">
          <button type="button" onClick={() => { if (feedMode !== "all") { setPosts(null); setFeedMode("all"); } }} className={`rounded-full px-3 py-1 text-xs font-medium ${feedMode === "all" ? "bg-clay text-white" : "bg-soft text-mute"}`}>For you</button>
          <button type="button" onClick={() => { if (feedMode !== "following") { setPosts(null); setFeedMode("following"); } }} className={`rounded-full px-3 py-1 text-xs font-medium ${feedMode === "following" ? "bg-clay text-white" : "bg-soft text-mute"}`}>Following</button>
        </div>
      </header>
      <form onSubmit={(event) => void onSubmit(event)} className="border-b border-line px-4 py-4 md:px-5">
        <div className="flex gap-3">
          <div className="hidden shrink-0 sm:block">
            {me ? (
              <Avatar name={me.displayName} url={me.avatarUrl} />
            ) : (
              <span className="block size-11 animate-pulse rounded-full bg-soft" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <label className="block">
              <span className="sr-only">Share a thought, photo or video</span>
              <textarea
                value={body}
                maxLength={POST_MAX}
                onChange={(event) => setBody(event.target.value)}
                onKeyDown={(event) => {
                  if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
                    event.preventDefault();
                    event.currentTarget.form?.requestSubmit();
                  }
                }}
                placeholder="What’s happening?"
                className={areaClass}
              />
            </label>
            {media ? (
              <div className="relative mt-3 overflow-hidden rounded-2xl border border-line bg-soft">
                {media.type === "image" ? <img src={media.url} alt="Selected upload preview" className="max-h-72 w-full object-contain" /> : <video src={media.url} controls className="max-h-72 w-full" />}
                <button type="button" onClick={() => setMedia(null)} className="absolute right-2 top-2 rounded-full bg-ink/80 px-3 py-1 text-xs text-white">Remove</button>
              </div>
            ) : null}
            <div className="mt-3 flex items-center justify-between gap-3">
              <span className={`text-xs tabular-nums ${body.length >= POST_MAX ? "text-clay" : "text-mute"}`}>
                {body.length}/{POST_MAX}
              </span>
              <div className="flex items-center gap-2">
                <label className="inline-flex h-10 cursor-pointer items-center rounded-full px-3 text-sm font-medium text-clay hover:bg-soft">
                  <span>＋ Media</span>
                  <input type="file" accept="image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,video/quicktime" className="sr-only" onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (!file) return;
                    if (file.size > 5 * 1024 * 1024) { setComposerError("Media must be 5 MB or smaller."); event.target.value = ""; return; }
                    const type = file.type.startsWith("image/") ? "image" : file.type.startsWith("video/") ? "video" : null;
                    if (!type) { setComposerError("Choose an image or video file."); return; }
                    const reader = new FileReader();
                    reader.onload = () => setMedia({ url: String(reader.result), type, name: file.name });
                    reader.readAsDataURL(file);
                    setComposerError(null);
                  }} />
                </label>
                <button type="submit" disabled={posting || (body.trim().length === 0 && !media)} className={buttonClass()}>
                {posting ? "Posting…" : "Post"}
              </button>
              </div>
            </div>
            {composerError ? (
              <p role="alert" className="mt-2 text-sm text-clay">
                {composerError}
              </p>
            ) : null}
          </div>
        </div>
      </form>
      {error ? (
        <div className="px-5 py-10 text-center">
          <p className="text-sm text-clay">{error}</p>
          <button type="button" onClick={() => void load()} className={`${buttonClass("secondary")} mt-4`}>
            Try again
          </button>
        </div>
      ) : posts === null ? (
        <div className="space-y-px">
          <div className="h-28 animate-pulse bg-soft/60" />
          <div className="h-28 animate-pulse bg-soft/40" />
          <div className="h-28 animate-pulse bg-soft/60" />
        </div>
      ) : posts.length === 0 ? (
        <div className="px-6 py-16 text-center">
          <Mark className="mx-auto size-10 text-ink" />
          <h2 className="mt-4 font-serif text-2xl font-medium">The room is quiet</h2>
          <p className="mx-auto mt-2 max-w-xs text-sm text-mute">
            {feedMode === "following" ? "Follow a few people and their posts will show up here." : "When someone posts, it will sit here at the top."}
          </p>
        </div>
      ) : (
        <div>
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onRemove={() => {
                setPosts((current) => (current ?? []).filter((item) => item.id !== post.id));
                void refresh();
              }}
            />
          ))}
        </div>
      )}
    </section>
  );
}
