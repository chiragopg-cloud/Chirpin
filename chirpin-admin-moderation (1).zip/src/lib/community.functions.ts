import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  BIO_MAX,
  COMMENT_MAX,
  HANDLE_RE,
  HEADLINE_MAX,
  LOCATION_MAX,
  NAME_MAX,
  POST_MAX,
} from "@/lib/limits";

/**
 * Shared room. Every signed-in member can read posts and public profiles.
 * Identity never comes from the client: authMiddleware supplies userId.
 * Profile edits, posts, comments, and likes are written only for that id.
 */

export type Profile = {
  displayName: string;
  handle: string;
  headline: string;
  bio: string;
  location: string;
  avatarUrl: string | null;
  joinedAt: string;
  postCount: number;
  likeCount: number;
  followerCount: number;
  followingCount: number;
  isFollowing: boolean;
  isSelf: boolean;
  isAdmin: boolean;
  isVerified: boolean;
  isVip: boolean;
};

export type Author = {
  displayName: string;
  handle: string;
  avatarUrl: string | null;
  isVerified: boolean;
  isVip: boolean;
};

export type Post = {
  id: number;
  body: string;
  mediaUrl: string | null;
  mediaType: "image" | "video" | null;
  createdAt: string;
  likeCount: number;
  liked: boolean;
  commentCount: number;
  mine: boolean;
  author: Author;
};

export type Comment = {
  id: number;
  parentId: number | null;
  body: string;
  createdAt: string;
  mine: boolean;
  author: Author;
};

type Ok<T> = { ok: true } & T;
type Err = { ok: false; message: string };

type ProfileRow = {
  user_id: string;
  display_name: string;
  handle: string;
  headline: string;
  bio: string;
  location: string;
  avatar_url: string | null;
  is_verified: unknown;
  is_vip: unknown;
  created_at: unknown;
};

type PostRow = {
  id: unknown;
  body: string;
  created_at: unknown;
  user_id: string;
  display_name: string;
  handle: string;
  avatar_url: string | null;
  like_count: unknown;
  liked: unknown;
  comment_count: unknown;
  media_url: string | null;
  media_type: string | null;
  is_verified: unknown;
  is_vip: unknown;
};

function asNum(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "bigint") return Number(value);
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) {
    return Number(value);
  }
  return 0;
}

function asBool(value: unknown): boolean {
  return value === true || value === "t" || value === "true" || value === 1;
}

function asIso(value: unknown): string {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString();
  if (typeof value === "string") {
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) return date.toISOString();
  }
  return new Date(0).toISOString();
}

function safeAvatar(url: string | null | undefined): string | null {
  if (!url) return null;
  return url.startsWith("https://") ? url : null;
}

function cleanLine(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.replace(/\u0000/g, "").replace(/\s+/g, " ").trim().slice(0, max);
}

function cleanBody(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.replace(/\u0000/g, "").replace(/\r\n/g, "\n").trim().slice(0, max);
}

async function containsBlockedWord(sql: Awaited<ReturnType<typeof getSql>>, text: string): Promise<boolean> {
  const rows = await sql<{ word: string }>`select word from blocked_words`;
  const normalized = text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").split(/\s+/).filter(Boolean);
  return rows.some(({ word }) => normalized.includes(word.toLowerCase()));
}

function slugHandle(input: string): string {
  const cleaned = input.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 16);
  return cleaned.length >= 3 ? cleaned : "member";
}

function isUnique(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const code = "code" in err ? String((err as { code: unknown }).code) : "";
  if (code === "23505") return true;
  const message = err instanceof Error ? err.message : String(err);
  return /unique|duplicate/i.test(message);
}

function mapProfile(
  row: ProfileRow & { follower_count?: unknown; following_count?: unknown; is_following?: unknown },
  postCount: number,
  likeCount: number,
  viewerId: string,
): Profile {
  return {
    displayName: row.display_name,
    handle: row.handle,
    headline: row.headline,
    bio: row.bio,
    location: row.location,
    avatarUrl: safeAvatar(row.avatar_url),
    joinedAt: asIso(row.created_at),
    postCount,
    likeCount,
    followerCount: asNum(row.follower_count),
    followingCount: asNum(row.following_count),
    isFollowing: asBool(row.is_following),
    isSelf: row.user_id === viewerId,
    isAdmin: false,
    isVerified: asBool(row.is_verified),
    isVip: asBool(row.is_vip),
  };
}

function mapPost(row: PostRow, viewerId: string): Post {
  return {
    id: Math.trunc(asNum(row.id)),
    body: row.body,
    createdAt: asIso(row.created_at),
    mediaUrl: row.media_url?.startsWith("data:image/") || row.media_url?.startsWith("data:video/") || row.media_url?.startsWith("https://") ? row.media_url : null,
    mediaType: row.media_type === "image" || row.media_type === "video" ? row.media_type : null,
    likeCount: asNum(row.like_count),
    liked: asBool(row.liked),
    commentCount: asNum(row.comment_count),
    mine: row.user_id === viewerId,
    author: {
      displayName: row.display_name,
      handle: row.handle,
      avatarUrl: safeAvatar(row.avatar_url),
      isVerified: asBool(row.is_verified),
      isVip: asBool(row.is_vip),
    },
  };
}

async function ensureProfile(sql: Awaited<ReturnType<typeof getSql>>, userId: string): Promise<ProfileRow> {
  const existing = await sql<ProfileRow>`
    select user_id, display_name, handle, headline, bio, location, avatar_url, is_verified, is_vip, created_at
    from profiles where user_id = ${userId}
  `;
  const authRows = await sql<{ name: string; email: string; image: string | null }>`
    select "name", "email", "image" from "user" where "id" = ${userId}
  `;
  const authUser = authRows[0];
  const avatar =
    authUser?.image && authUser.image.startsWith("https://") ? authUser.image : null;

  if (existing[0]) {
    if (!existing[0].avatar_url && avatar) {
      const updated = await sql<ProfileRow>`
        update profiles set avatar_url = ${avatar}
        where user_id = ${userId} and avatar_url is null
        returning user_id, display_name, handle, headline, bio, location, avatar_url, is_verified, is_vip, created_at
      `;
      return updated[0] ?? existing[0];
    }
    return existing[0];
  }

  const displayName = cleanLine(authUser?.name || "Member", NAME_MAX) || "Member";
  const seed = slugHandle((authUser?.email || displayName).split("@")[0] || displayName);

  for (let i = 0; i < 30; i += 1) {
    const handle = i === 0 ? seed : `${seed.slice(0, 14)}${i + 1}`;
    try {
      const inserted = await sql<ProfileRow>`
        insert into profiles (user_id, display_name, handle, avatar_url)
        values (${userId}, ${displayName}, ${handle}, ${avatar})
        returning user_id, display_name, handle, headline, bio, location, avatar_url, is_verified, is_vip, created_at
      `;
      if (inserted[0]) return inserted[0];
    } catch (err) {
      if (!isUnique(err)) throw err;
      const again = await sql<ProfileRow>`
        select user_id, display_name, handle, headline, bio, location, avatar_url, is_verified, is_vip, created_at
        from profiles where user_id = ${userId}
      `;
      if (again[0]) return again[0];
    }
  }
  throw new Error("Could not create your profile");
}

async function readProfile(
  sql: Awaited<ReturnType<typeof getSql>>,
  viewerId: string,
  where: "self" | "handle",
  handle?: string,
): Promise<Profile | null> {
  const rows =
    where === "self"
      ? await sql<ProfileRow & { post_count: unknown; like_count: unknown; follower_count: unknown; following_count: unknown; is_following: unknown }>`
          select
            profiles.user_id, profiles.display_name, profiles.handle, profiles.headline,
            profiles.bio, profiles.location, profiles.avatar_url, profiles.is_verified, profiles.is_vip, profiles.created_at,
            (select count(*) from posts where posts.user_id = profiles.user_id) as post_count,
            (select count(*) from likes
               join posts on posts.id = likes.post_id
               where posts.user_id = profiles.user_id) as like_count,
            (select count(*) from follows where following_id = profiles.user_id) as follower_count,
            (select count(*) from follows where follower_id = profiles.user_id) as following_count,
            exists(select 1 from follows where follower_id = ${viewerId} and following_id = profiles.user_id) as is_following
          from profiles
          where profiles.user_id = ${viewerId}
        `
      : await sql<ProfileRow & { post_count: unknown; like_count: unknown; follower_count: unknown; following_count: unknown; is_following: unknown }>`
          select
            profiles.user_id, profiles.display_name, profiles.handle, profiles.headline,
            profiles.bio, profiles.location, profiles.avatar_url, profiles.is_verified, profiles.is_vip, profiles.created_at,
            (select count(*) from posts where posts.user_id = profiles.user_id) as post_count,
            (select count(*) from likes
               join posts on posts.id = likes.post_id
               where posts.user_id = profiles.user_id) as like_count,
            (select count(*) from follows where following_id = profiles.user_id) as follower_count,
            (select count(*) from follows where follower_id = profiles.user_id) as following_count,
            exists(select 1 from follows where follower_id = ${viewerId} and following_id = profiles.user_id) as is_following
          from profiles
          where profiles.handle = ${handle ?? ""}
        `;
  const row = rows[0];
  if (!row) return null;
  const profile = mapProfile(row, asNum(row.post_count), asNum(row.like_count), viewerId);
  const authRows = await sql<{ email: string }>`select email from "user" where id = ${row.user_id}`;
  const allowedAdmins = (process.env.ADMIN_EMAILS ?? "").split(",").map((email) => email.trim().toLowerCase()).filter(Boolean);
  profile.isAdmin = Boolean(authRows[0]?.email && allowedAdmins.includes(authRows[0].email.toLowerCase()));
  return profile;
}

async function fetchPosts(
  sql: Awaited<ReturnType<typeof getSql>>,
  viewerId: string,
  authorId: string | null,
  followingOnly = false,
): Promise<Post[]> {
  const params: unknown[] = [viewerId];
  let where = "";
  if (authorId) {
    params.push(authorId);
    where = "where posts.user_id = $2";
  } else if (followingOnly) {
    where = "where (posts.user_id = $1 or posts.user_id in (select following_id from follows where follower_id = $1))";
  }
  const rows = await sql.query<PostRow>(
    `select
       posts.id, posts.body, posts.created_at, posts.user_id,
       profiles.display_name, profiles.handle, profiles.avatar_url, profiles.is_verified, profiles.is_vip,
       (select count(*) from likes where likes.post_id = posts.id) as like_count,
       exists(select 1 from likes where likes.post_id = posts.id and likes.user_id = $1) as liked,
       (select count(*) from comments where comments.post_id = posts.id) as comment_count,
       posts.media_url, posts.media_type
     from posts
     join profiles on profiles.user_id = posts.user_id
     ${where}
     order by posts.created_at desc, posts.id desc
     limit 50`,
    params,
  );
  return rows.map((row) => mapPost(row, viewerId));
}

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Profile> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const profile = await readProfile(sql, context.userId, "self");
    if (!profile) throw new Error("Could not load your profile");
    return profile;
  });

export const getByHandle = createServerFn({ method: "GET" })
  .validator((handle: string) => {
    if (typeof handle !== "string") throw new Error("Invalid handle");
    return handle.trim().toLowerCase();
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Profile | null> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    if (!HANDLE_RE.test(data)) return null;
    return readProfile(sql, context.userId, "handle", data);
  });

export const updateProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ profile: Profile }> | Err> => {
    const raw = data && typeof data === "object" ? (data as Record<string, unknown>) : {};
    const displayName = cleanLine(raw.displayName, NAME_MAX);
    const handle = cleanLine(raw.handle, 32).toLowerCase();
    const headline = cleanLine(raw.headline, HEADLINE_MAX);
    const bio = cleanBody(raw.bio, BIO_MAX);
    const location = cleanLine(raw.location, LOCATION_MAX);
    if (!displayName) return { ok: false, message: "Name is required." };
    if (!HANDLE_RE.test(handle)) {
      return { ok: false, message: "Handle is 3–20 letters, numbers, or underscores." };
    }
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    try {
      const updated = await sql<ProfileRow>`
        update profiles
        set display_name = ${displayName},
            handle = ${handle},
            headline = ${headline},
            bio = ${bio},
            location = ${location},
            updated_at = now()
        where user_id = ${context.userId}
        returning user_id, display_name, handle, headline, bio, location, avatar_url, is_verified, is_vip, created_at
      `;
      if (!updated[0]) return { ok: false, message: "Could not save your profile." };
    } catch (err) {
      if (isUnique(err)) return { ok: false, message: "That handle is taken." };
      throw err;
    }
    const profile = await readProfile(sql, context.userId, "self");
    if (!profile) return { ok: false, message: "Could not save your profile." };
    return { ok: true, profile };
  });

export const listFeed = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Post[]> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    return fetchPosts(sql, context.userId, null);
  });

export const listFollowingFeed = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Post[]> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    return fetchPosts(sql, context.userId, null, true);
  });

export const listPosts = createServerFn({ method: "GET" })
  .validator((handle: string | null) => {
    if (handle == null || handle === "") return null;
    if (typeof handle !== "string") throw new Error("Invalid handle");
    return handle.trim().toLowerCase();
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Post[]> => {
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId);
    if (!data) return fetchPosts(sql, context.userId, me.user_id);
    if (!HANDLE_RE.test(data)) return [];
    const found = await sql<{ user_id: string }>`select user_id from profiles where handle = ${data}`;
    if (!found[0]) return [];
    return fetchPosts(sql, context.userId, found[0].user_id);
  });

export const createPost = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ post: Post }> | Err> => {
    const raw = data && typeof data === "object" ? (data as Record<string, unknown>) : {};
    const body = cleanBody(raw.body, POST_MAX + 1);
    const mediaUrl = typeof raw.mediaUrl === "string" ? raw.mediaUrl : null;
    const mediaType = raw.mediaType === "image" || raw.mediaType === "video" ? raw.mediaType : null;
    if (mediaUrl && (!mediaType || !/^data:(image\/(jpeg|png|gif|webp)|video\/(mp4|webm|quicktime));base64,/.test(mediaUrl) || mediaUrl.length > 7_500_000)) return { ok: false, message: "Choose an image or video under 5 MB." };
    if (!body && !mediaUrl) return { ok: false, message: "Write something or attach media first." };
    if (body.length > POST_MAX) return { ok: false, message: `Keep it under ${POST_MAX} characters.` };
    const sql = await getSql();
    if (await containsBlockedWord(sql, body)) return { ok: false, message: "Your post contains a blocked word. Please edit it and try again." };
    const profile = await ensureProfile(sql, context.userId);
    const inserted = await sql<{ id: unknown; created_at: unknown }>`
      insert into posts (user_id, body, media_url, media_type) values (${context.userId}, ${body}, ${mediaUrl}, ${mediaType})
      returning id, created_at
    `;
    const row = inserted[0];
    if (!row) return { ok: false, message: "Could not post." };
    const post: Post = {
      id: Math.trunc(asNum(row.id)),
      body,
      mediaUrl,
      mediaType,
      createdAt: asIso(row.created_at),
      likeCount: 0,
      liked: false,
      commentCount: 0,
      mine: true,
      author: {
        displayName: profile.display_name,
        handle: profile.handle,
        avatarUrl: safeAvatar(profile.avatar_url),
        isVerified: asBool(profile.is_verified),
        isVip: asBool(profile.is_vip),
      },
    };
    return { ok: true, post };
  });

export const deletePost = createServerFn({ method: "POST" })
  .validator((id: unknown) => Math.trunc(asNum(id)))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    if (data <= 0) return { ok: false, message: "That post is gone." };
    const sql = await getSql();
    const removed = await sql<{ id: unknown }>`
      delete from posts where id = ${data} and user_id = ${context.userId} returning id
    `;
    if (!removed[0]) return { ok: false, message: "That post is gone." };
    return { ok: true };
  });

export const toggleLike = createServerFn({ method: "POST" })
  .validator((id: unknown) => Math.trunc(asNum(id)))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ liked: boolean; likeCount: number }> | Err> => {
    if (data <= 0) return { ok: false, message: "That post is gone." };
    const sql = await getSql();
    const posts = await sql<{ id: unknown }>`select id from posts where id = ${data}`;
    if (!posts[0]) return { ok: false, message: "That post is gone." };
    const removed = await sql<{ post_id: unknown }>`
      delete from likes where post_id = ${data} and user_id = ${context.userId} returning post_id
    `;
    let liked = false;
    if (!removed[0]) {
      await sql`insert into likes (post_id, user_id) values (${data}, ${context.userId})`;
      liked = true;
    }
    const counts = await sql<{ c: unknown }>`select count(*) as c from likes where post_id = ${data}`;
    return { ok: true, liked, likeCount: asNum(counts[0]?.c) };
  });

export const listComments = createServerFn({ method: "GET" })
  .validator((id: unknown) => Math.trunc(asNum(id)))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Comment[]> => {
    if (data <= 0) return [];
    const sql = await getSql();
    const rows = await sql<{
      id: unknown;
      parent_id: unknown;
      body: string;
      created_at: unknown;
      user_id: string;
      display_name: string;
      handle: string;
      avatar_url: string | null;
      is_verified: unknown;
      is_vip: unknown;
    }>`
      select comments.id, comments.parent_id, comments.body, comments.created_at, comments.user_id,
             profiles.display_name, profiles.handle, profiles.avatar_url, profiles.is_verified, profiles.is_vip
      from comments
      join profiles on profiles.user_id = comments.user_id
      where comments.post_id = ${data}
      order by comments.created_at asc, comments.id asc
      limit 100
    `;
    return rows.map((row) => ({
      id: Math.trunc(asNum(row.id)),
      parentId: row.parent_id == null ? null : Math.trunc(asNum(row.parent_id)),
      body: row.body,
      createdAt: asIso(row.created_at),
      mine: row.user_id === context.userId,
      author: {
        displayName: row.display_name,
        handle: row.handle,
        avatarUrl: safeAvatar(row.avatar_url),
        isVerified: asBool(row.is_verified),
        isVip: asBool(row.is_vip),
      },
    }));
  });

export const addComment = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ comment: Comment }> | Err> => {
    const raw = data && typeof data === "object" ? (data as Record<string, unknown>) : {};
    const postId = Math.trunc(asNum(raw.postId));
    const body = cleanBody(raw.body, COMMENT_MAX + 1);
    const parentId = raw.parentId == null ? null : Math.trunc(asNum(raw.parentId));
    if (postId <= 0) return { ok: false, message: "That post is gone." };
    if (!body) return { ok: false, message: "Write a reply first." };
    if (body.length > COMMENT_MAX) {
      return { ok: false, message: `Replies stay under ${COMMENT_MAX} characters.` };
    }
    const sql = await getSql();
    if (await containsBlockedWord(sql, body)) return { ok: false, message: "Your reply contains a blocked word. Please edit it and try again." };
    const profile = await ensureProfile(sql, context.userId);
    const posts = await sql<{ id: unknown }>`select id from posts where id = ${postId}`;
    if (!posts[0]) return { ok: false, message: "That post is gone." };
    if (parentId !== null) {
      const parent = await sql<{ id: unknown }>`select id from comments where id = ${parentId} and post_id = ${postId}`;
      if (!parent[0]) return { ok: false, message: "That reply is no longer available." };
    }
    const inserted = await sql<{ id: unknown; created_at: unknown }>`
      insert into comments (post_id, user_id, body, parent_id)
      values (${postId}, ${context.userId}, ${body}, ${parentId})
      returning id, created_at
    `;
    const row = inserted[0];
    if (!row) return { ok: false, message: "Could not reply." };
    return {
      ok: true,
      comment: {
        id: Math.trunc(asNum(row.id)),
        parentId,
        body,
        createdAt: asIso(row.created_at),
        mine: true,
        author: {
          displayName: profile.display_name,
          handle: profile.handle,
          avatarUrl: safeAvatar(profile.avatar_url),
          isVerified: asBool(profile.is_verified),
          isVip: asBool(profile.is_vip),
        },
      },
    };
  });

export const deleteComment = createServerFn({ method: "POST" })
  .validator((id: unknown) => Math.trunc(asNum(id)))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true } | Err> => {
    if (data <= 0) return { ok: false, message: "That reply is gone." };
    const sql = await getSql();
    const removed = await sql<{ id: unknown }>`
      delete from comments where id = ${data} and user_id = ${context.userId} returning id
    `;
    if (!removed[0]) return { ok: false, message: "That reply is gone." };
    return { ok: true };
  });


export const toggleFollow = createServerFn({ method: "POST" })
  .validator((handle: unknown) => (typeof handle === "string" ? handle.trim().toLowerCase() : ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ following: boolean; followerCount: number }> | Err> => {
    if (!HANDLE_RE.test(data)) return { ok: false, message: "That profile is unavailable." };
    const sql = await getSql();
    const target = await sql<{ user_id: string }>`select user_id from profiles where handle = ${data}`;
    if (!target[0] || target[0].user_id === context.userId) return { ok: false, message: "You can't follow this profile." };
    const removed = await sql<{ follower_id: string }>`delete from follows where follower_id = ${context.userId} and following_id = ${target[0].user_id} returning follower_id`;
    const following = !removed[0];
    if (following) await sql`insert into follows (follower_id, following_id) values (${context.userId}, ${target[0].user_id}) on conflict do nothing`;
    const count = await sql<{ c: unknown }>`select count(*) as c from follows where following_id = ${target[0].user_id}`;
    return { ok: true, following, followerCount: asNum(count[0]?.c) };
  });
