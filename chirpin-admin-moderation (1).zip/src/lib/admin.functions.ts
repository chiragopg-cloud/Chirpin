import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";

type AdminProfile = { userId: string; displayName: string; handle: string; email: string; isVerified: boolean; isVip: boolean; isBanned: boolean; joinedAt: string };

async function requireAdmin(sql: Awaited<ReturnType<typeof getSql>>, userId: string) {
  const rows = await sql<{ email: string }>`select email from "user" where id = ${userId}`;
  const email = rows[0]?.email?.trim().toLowerCase();
  const allowed = (process.env.ADMIN_EMAILS ?? "").split(",").map((item) => item.trim().toLowerCase()).filter(Boolean);
  if (!email || !allowed.includes(email)) throw new Error("Admin access required.");
}

export const listAdminProfiles = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<AdminProfile[]> => {
    const sql = await getSql();
    await requireAdmin(sql, context.userId);
    const rows = await sql<{ user_id: string; display_name: string; handle: string; email: string; is_verified: boolean; is_vip: boolean; is_banned: boolean; created_at: unknown }>`
      select p.user_id, p.display_name, p.handle, u.email, p.is_verified, p.is_vip, p.is_banned, p.created_at
      from profiles p join "user" u on u.id = p.user_id order by p.created_at desc limit 200
    `;
    return rows.map((row) => ({ userId: row.user_id, displayName: row.display_name, handle: row.handle, email: row.email, isVerified: row.is_verified === true, isVip: row.is_vip === true, isBanned: row.is_banned === true, joinedAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at) }));
  });

export const setProfileBadges = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Invalid badge update.");
    const value = input as Record<string, unknown>;
    if (typeof value.userId !== "string" || value.userId.length < 1 || value.userId.length > 200) throw new Error("Invalid member.");
    if (typeof value.isVerified !== "boolean" || typeof value.isVip !== "boolean") throw new Error("Invalid badge values.");
    return { userId: value.userId, isVerified: value.isVerified, isVip: value.isVip };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await requireAdmin(sql, context.userId);
    const updated = await sql<{ user_id: string }>`update profiles set is_verified = ${data.isVerified}, is_vip = ${data.isVip}, updated_at = now() where user_id = ${data.userId} returning user_id`;
    if (!updated[0]) throw new Error("Member profile not found.");
    return { ok: true as const };
  });

export type AdminPost = { id: number; body: string; mediaType: string | null; mediaUrl: string | null; handle: string; createdAt: string };
export const listAdminPosts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(async ({ context }): Promise<AdminPost[]> => {
  const sql = await getSql(); await requireAdmin(sql, context.userId);
  const rows = await sql<{id: unknown; body: string; media_type: string | null; media_url: string | null; handle: string; created_at: unknown}>`
    select p.id,p.body,p.media_type,p.media_url,pr.handle,p.created_at from posts p join profiles pr on pr.user_id=p.user_id order by p.created_at desc limit 100`;
  return rows.map(r => ({id:Number(r.id),body:r.body,mediaType:r.media_type,mediaUrl:r.media_url,handle:r.handle,createdAt:r.created_at instanceof Date?r.created_at.toISOString():String(r.created_at)}));
});
export const adminDeletePost = createServerFn({ method: "POST" }).validator((v: unknown) => { const n=Number(v); if(!Number.isInteger(n)||n<1) throw new Error("Invalid post."); return n; }).middleware([authMiddleware]).handler(async ({context,data}) => { const sql=await getSql(); await requireAdmin(sql,context.userId); await sql`delete from posts where id=${data}`; return {ok:true as const}; });
export const setAccountBan = createServerFn({ method: "POST" }).validator((v: unknown) => { if(!v||typeof v!=="object") throw new Error("Invalid request."); const x=v as Record<string,unknown>; if(typeof x.userId!=="string"||typeof x.banned!=="boolean"||typeof x.reason!=="string") throw new Error("Invalid ban details."); return {userId:x.userId,banned:x.banned,reason:x.reason.slice(0,300)}; }).middleware([authMiddleware]).handler(async ({context,data}) => { const sql=await getSql(); await requireAdmin(sql,context.userId); if(data.userId===context.userId) throw new Error("You cannot ban your own admin account."); const rows=await sql`update profiles set is_banned=${data.banned}, ban_reason=${data.banned?data.reason:""}, updated_at=now() where user_id=${data.userId} returning user_id`; if(!rows[0]) throw new Error("Member not found."); return {ok:true as const}; });
export const listBlockedWords = createServerFn({method:"GET"}).middleware([authMiddleware]).handler(async({context})=>{const sql=await getSql();await requireAdmin(sql,context.userId);return sql<{id:number;word:string}>`select id,word from blocked_words order by word asc`;});
export const addBlockedWord = createServerFn({method:"POST"}).validator((v:unknown)=>{if(typeof v!=="string")throw new Error("Enter a word.");const word=v.trim().toLowerCase();if(word.length<2||word.length>40||/\s/.test(word))throw new Error("Use one word (2–40 characters).");return word;}).middleware([authMiddleware]).handler(async({context,data})=>{const sql=await getSql();await requireAdmin(sql,context.userId);await sql`insert into blocked_words(word) values(${data}) on conflict(word) do nothing`;return {ok:true as const};});
export const removeBlockedWord = createServerFn({method:"POST"}).validator((v:unknown)=>{const n=Number(v);if(!Number.isInteger(n)||n<1)throw new Error("Invalid word.");return n;}).middleware([authMiddleware]).handler(async({context,data})=>{const sql=await getSql();await requireAdmin(sql,context.userId);await sql`delete from blocked_words where id=${data}`;return {ok:true as const};});
