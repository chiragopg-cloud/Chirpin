export const POST_MAX = 480;
export const COMMENT_MAX = 240;
export const NAME_MAX = 40;
export const HANDLE_MIN = 3;
export const HANDLE_MAX = 20;
export const HEADLINE_MAX = 80;
export const BIO_MAX = 160;
export const LOCATION_MAX = 40;

export const HANDLE_RE = /^[a-z0-9_]{3,20}$/;
