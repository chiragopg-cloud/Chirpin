-- Chirpin: one shared room. Profiles are per member; posts are visible to
-- every signed-in member. Writes are still scoped to the author.

create table if not exists profiles (
  user_id text primary key,
  display_name text not null,
  handle text not null unique,
  headline text not null default '',
  bio text not null default '',
  location text not null default '',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists posts (
  id serial primary key,
  user_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create index if not exists posts_created_idx on posts (created_at desc, id desc);
create index if not exists posts_user_idx on posts (user_id, created_at desc);

create table if not exists likes (
  post_id integer not null references posts (id) on delete cascade,
  user_id text not null,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists comments (
  id serial primary key,
  post_id integer not null references posts (id) on delete cascade,
  user_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create index if not exists comments_post_idx on comments (post_id, created_at, id);
