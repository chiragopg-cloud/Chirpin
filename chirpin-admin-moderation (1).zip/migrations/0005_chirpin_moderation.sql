alter table profiles add column if not exists is_banned boolean not null default false;
alter table profiles add column if not exists ban_reason text not null default '';
create table if not exists blocked_words (
  id serial primary key,
  word text not null unique,
  created_at timestamptz not null default now()
);
