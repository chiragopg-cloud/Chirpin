-- Profile badges are controlled by server-side admin actions only.
alter table profiles add column if not exists is_verified boolean not null default false;
alter table profiles add column if not exists is_vip boolean not null default false;
