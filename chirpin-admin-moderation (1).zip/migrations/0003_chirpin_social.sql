-- Chirpin social graph, threaded replies, and lightweight media attachments.
create table if not exists follows (
  follower_id text not null,
  following_id text not null,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);
create index if not exists follows_following_idx on follows (following_id, created_at desc);
alter table comments add column if not exists parent_id integer references comments(id) on delete cascade;
create index if not exists comments_parent_idx on comments (parent_id, created_at, id);
alter table posts add column if not exists media_url text;
alter table posts add column if not exists media_type text;
